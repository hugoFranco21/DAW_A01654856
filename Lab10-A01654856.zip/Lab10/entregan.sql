SET DATEFORMAT dmy

BULK INSERT a1654856.a1654856.[Entregan]
FROM 'e:\wwwroot\a1654856\entregan.csv'
WITH 
(
	CODEPAGE = 'ACP',
	FIELDTERMINATOR = ',',
	ROWTERMINATOR = '\n'
)

SELECT * FROM Entregan
